const { cakeActions } = require("../cake/cakeSlice");

// import yourThing from ‘yourLibrary’; // use this style in react code
const createSlice = require("@reduxjs/toolkit").createSlice;

const initialState = {
  numberOfIcecream: 10,
};

const icecreamSlice = createSlice({
  // the func accept 3 properties name, initial state, reducers
  name: "icecream",
  initialState, // or we can write as well - initialState: initialState,
  reducers: {
    ordered: (state) => {
      // function accept two params state and action
      // we don't need action as there is no payload
      state.numberOfIcecream--;
    },
    restocked: (state, action) => {
      // function accept two params state and action
      // we need action as there is some payload
      state.numberOfIcecream += action.payload;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(cakeActions.ordered, (state) => {
      state.numberOfIcecream--;
    });
  },
});

module.exports = icecreamSlice.reducer;
module.exports.icecreamActions = icecreamSlice.actions; // to reduce boilerplate code for action name, action creators
// export default yourThing; // in react
