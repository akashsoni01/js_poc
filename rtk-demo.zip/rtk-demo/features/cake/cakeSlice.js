// import yourThing from ‘yourLibrary’; // use this style in react code
const createSlice = require("@reduxjs/toolkit").createSlice;

const initialState = {
  numberOfCake: 10,
};

const cakeSlice = createSlice({
  // the func accept 3 properties name, initial state, reducers
  name: "cake",
  initialState, // or we can write as well - initialState: initialState,
  reducers: {
    ordered: (state) => {
      // function accept two params state and action
      // we don't need action as there is no payload
      state.numberOfCake--;
    },
    restocked: (state, action) => {
      // function accept two params state and action
      // we need action as there is some payload
      state.numberOfCake += action.payload;
    },
  },
});

module.exports = cakeSlice.reducer;
module.exports.cakeActions = cakeSlice.actions; // to reduce boilerplate code for action name, action creators
// export default yourThing; // in react
