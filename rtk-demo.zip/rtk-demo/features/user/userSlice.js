const { createAsyncThunk } = require("@reduxjs/toolkit");
const axios = require("axios");

// import yourThing from ‘yourLibrary’; // use this style in react code
const createSlice = require("@reduxjs/toolkit").createSlice;

const initialState = {
  loading: false,
  users: [],
  error: "",
};
// generates pending, fullfilled and rejected actinos
const fetchUsers = createAsyncThunk("user/fetchUsers", () => {
  return axios
    .get("https://jsonplaceholder.typicode.com/users")
    .then((response) => response.data.map((user) => user.id));
});

const userSlice = createSlice({
  // the func accept 3 properties name, initial state, reducers
  name: "user",
  initialState, // or we can write as well - initialState: initialState,
  extraReducers: (builder) => {
    builder.addCase(fetchUsers.pending, (state) => {
      state.loading = true;
    });
    builder.addCase(fetchUsers.fulfilled, (state, action) => {
      state.loading = false;
      state.users = action.payload;
      state.error = "";
    });
    builder.addCase(fetchUsers.rejected, (state, action) => {
      state.loading = false;
      state.users = [];
      state.error = action.error.message;
    });
  },
});

module.exports = userSlice.reducer;
module.exports.fetchUsers = fetchUsers; // to reduce boilerplate code for action name, action creators
// export default yourThing; // in react
