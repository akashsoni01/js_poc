// import yourThing from ‘yourLibrary’; // use this style in react code
const configureStore = require("@reduxjs/toolkit").configureStore;
// const reduxLogger = require("redux-logger");
// const logger = reduxLogger.createLogger();
const thunkMiddleware = require("redux-thunk").default;

const cakeReducer = require("../features/cake/cakeSlice");
const icecreamReducer = require("../features/icecream/icecreamSlice");
const userReducer = require("../features/user/userSlice");

const store = configureStore({
  reducer: {
    cake: cakeReducer,
    icecream: icecreamReducer,
    user: userReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(thunkMiddleware),
});

module.exports = store;
// export default yourThing; // in react
