// import yourThing from ‘yourLibrary’; // use this style in react code
const store = require("./app/store");
const cakeAction = require("./features/cake/cakeSlice").cakeActions;
const icecreamAction =
  require("./features/icecream/icecreamSlice").icecreamActions;
const fetchUsers = require("./features/user/userSlice").fetchUsers;

console.log("initial state", store.getState());

const unsubscribe = store.subscribe(() => {
  console.log("Update State", store.getState());
});

store.dispatch(fetchUsers());

// unsubscribe(); // hide this line if you are testing async funciton
