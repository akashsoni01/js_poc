import { configureStore } from '@reduxjs/toolkit'
import { postsApiSlice } from '../features/api/postsApiSlice'

export default configureStore({
    reducer: {
        // posts: postsReducer,
        // users: usersReducer,
        // notifications: notificationsReducer,
        [postsApiSlice.reducerPath]: postsApiSlice.reducer
    },
    middleware: getDefaultMiddleware =>
        getDefaultMiddleware().concat(postsApiSlice.middleware)
})


