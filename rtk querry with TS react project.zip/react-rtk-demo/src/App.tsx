import { useState } from 'react'
import './App.css'

import { UserView } from './features/user/UserView'
function App() {
  return (
    <div className="App">
      <UserView />
    </div>
  )
}

export default App
