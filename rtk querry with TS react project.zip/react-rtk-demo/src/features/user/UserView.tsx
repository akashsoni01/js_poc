import React from 'react'
import { useGetPostsQuery } from '../api/postsApiSlice'
export const UserView = () => {
    const { data, error, isLoading, isFetching, isError, isSuccess } = useGetPostsQuery()
    return (
        <div>
            <h2>List of Users</h2>
            {isLoading && <h2>..Loading</h2>}
            {isFetching && <h2>...Featching</h2>}
            {isError && <h2>Someting Went Wrong  </h2>}
            {isSuccess && (
                <ul>
                    {
                        data?.map((post) => {
                            return <div>
                                <li key={post.userId} > {post.title}</li>
                                <span key={post.userId}>
                                    {post.userId}
                                    {post.title}
                                    {post.body}
                                </span>
                            </div>
                        })}
                </ul>
            )}
        </div>
    )
}
