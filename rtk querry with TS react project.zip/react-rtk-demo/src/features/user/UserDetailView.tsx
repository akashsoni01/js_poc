import React from 'react'
import { useGetPostQuery } from '../api/postsApiSlice'
export const UserDetailView = (userId: string) => {
    const { data, error, isLoading, isFetching, isError, isSuccess } = useGetPostQuery(userId)
    return (
        <div>
            <h2>List of Users</h2>
            {isLoading && <h2>..Loading</h2>}
            {isFetching && <h2>...Featching</h2>}
            {isError && <h2>Someting Went Wrong  </h2>}
            {isSuccess && (
                <pre>
                    {JSON.stringify(data, undefined, 2)}
                </pre>
            )}
        </div>
    )
}
