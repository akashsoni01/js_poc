import React from 'react'

export const IceCreamView = () => {
  return (
    <div>
      <h2>Number of Ice Cream - </h2>
      <button>Order Ice Cream</button>
      <button>Restoke Ice Cream</button>
    </div>
  )
}
