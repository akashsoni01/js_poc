import React from 'react'

export const CakeView = () => {
    return (
        <div>
            <h2>Number of Cakes - </h2>
            <button>Order Cake</button>
            <button>Restoke Cake</button>
        </div>
    )
}
