import React from 'react'

export const UserView = () => {
    return (
        <div>
            <h2>
                List of Users
            </h2>
        </div>
    )
}
