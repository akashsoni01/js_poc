// import redux from 'redux'; // can use in react but not in node application so use require
const redux = require("redux");
const createStore = redux.createStore;
const bindActionCreators = redux.bindActionCreators;
const combineReducers = redux.combineReducers;
const applyMiddleware = redux.applyMiddleware;
const reduxLogger = require("redux-logger");
const logger = reduxLogger.createLogger();

// ACTION NAME
const CAKE_ORDERED = "CAKE_ORDERED";
const CAKE_RESTOCKED = "CAKE_RESTOCKED";
const ICECREAM_ORDERED = "ICECREAM_ORDERED";
const ICECREAM_RESTOCKED = "ICECREAM_RESTOCKED";

// ACTION CREATOR - THAT IS A FUNCTION that reaturn an funciton

function orderCake() {
  return {
    type: CAKE_ORDERED,
    payload: 1,
  };
}

function restockCake(quantity = 1) {
  return {
    type: CAKE_RESTOCKED,
    payload: quantity,
  };
}

function orderIcecream() {
  return {
    type: ICECREAM_ORDERED,
    payload: 1,
  };
}

function restockIcecream(quantity = 1) {
  return {
    type: ICECREAM_RESTOCKED,
    payload: quantity,
  };
}

// State - state is an object
const initialCakeState = {
  numberOfCakes: 10,
};

const initialIceCreamState = {
  numberOfIcecreams: 10,
};

// Reducer - reducer takes previous state and action and return new state
// (previousState, action ) => newState

const cakeReducer = (state = initialCakeState, action) => {
  switch (action.type) {
    case CAKE_ORDERED:
      return {
        ...state, // ... dot denote copy syntax
        numberOfCakes: state.numberOfCakes - 1, // we can crete a new object by changeing one or more property
      };

    case CAKE_RESTOCKED:
      return {
        ...state, // ... dot denote copy syntax
        numberOfCakes: state.numberOfCakes + action.payload, // we can crete a new object by changeing one or more property
      };

    default:
      return state;
  }
};

const iceCreamReducer = (state = initialIceCreamState, action) => {
  switch (action.type) {
    case ICECREAM_ORDERED:
      return {
        ...state, // ... dot denote copy syntax
        numberOfIcecreams: state.numberOfIcecreams - 1, // we can crete a new object by changeing one or more property
      };

    case ICECREAM_RESTOCKED:
      return {
        ...state, // ... dot denote copy syntax
        numberOfCakes: state.numberOfIcecreams + action.payload, // we can crete a new object by changeing one or more property
      };

    default:
      return state;
  }
};

const rootReducer = combineReducers({
  cake: cakeReducer,
  iceCream: iceCreamReducer,
});

const store = createStore(rootReducer, applyMiddleware(logger));
console.log("Initial state", store.getState());

const unsubscribe = store.subscribe(() =>
  console.log("Update state", store.getState())
);

const actions = bindActionCreators(
  { orderCake, restockCake, orderIcecream, restockIcecream },
  store.dispatch
);
actions.orderCake();
actions.orderCake();
actions.restockIcecream(5);
actions.orderCake();
actions.restockCake(5);

unsubscribe();
