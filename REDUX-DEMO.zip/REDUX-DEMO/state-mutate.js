// import redux from 'redux'; // can use in react but not in node application so use require
const redux = require("redux");
const produce = require("immer").produce;

// State - state is an object
const initialState = {
  name: "akash soni",
  address: {
    street: "youou",
    city: "moij",
    state: "up",
  },
};

// ACTION NAME
const UPDATE_STREET = "UPDATE_STREET";

// ACTION CREATOR - THAT IS A FUNCTION that reaturn an funciton
const updateStreet = (street) => {
  return {
    type: UPDATE_STREET,
    payload: street,
  };
};

// Reducer - reducer takes previous state and action and return new state
// (previousState, action ) => newState

const reducer = (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_STREET:
        // return {
        //   ...state, // ... dot denote copy syntax
        //   address: {
        //     ...state.address,
        //     street: action.payload,
        //   }, // we can crete a new object by changeing one or more property
        // };
      return produce(state, (draftState) => {
        draftState.address.street = action.payload;
      });

    default:
      return state;
  }
};

const store = redux.createStore(reducer);
console.log("Initial state", store.getState());

const unsubscribe = store.subscribe(() =>
  console.log("Update state", store.getState())
);

store.dispatch(updateStreet("hello world"));
unsubscribe();
