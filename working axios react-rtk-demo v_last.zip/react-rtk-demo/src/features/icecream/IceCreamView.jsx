import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { ordered, restocked } from './icecreamSlice'

export const IceCreamView = () => {
  const numberOfIceCream = useSelector((state) => state.icecream.numberOfIcecream) // reducer slice name accessing someState that are getting stored in prop someProp
  const dispatch = useDispatch();
  return (
    <div>
      <h2>Number of Ice Cream - {numberOfIceCream}</h2>
      <button onClick={() => dispatch(ordered())}>Order Ice Cream</button>
      <button onClick={() => dispatch(restocked(22))}>Restoke Ice Cream</button>
    </div>
  )
}
