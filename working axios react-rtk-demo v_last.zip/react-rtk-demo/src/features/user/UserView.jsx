import { useEffect } from "react"
import React from 'react'
import { useDispatch, useSelector } from "react-redux"
import { fetchUsers as fetchUersApi } from "./userSlice"

export const UserView = () => {
    const user = useSelector((state) => state.user)
    const dispatch = useDispatch() // to dispatch 
    useEffect(() => {
        // need to dispatch an async action from here 
        dispatch(fetchUersApi())
    }, []) // function has to input param first is a callback function and second dependency list
    return (
        <div>
            <h2>
                List of Users
            </h2>
            {user.loading && <div>Loading ..... </div>}
            {!user.loading && user.error ? <div>Error {user.error}</div> : null}
            {!user.loading && user.users.length ? (
                <ul>
                    {
                        user.users.map((user) => {
                            return <li key={user.id} > {user.name}</li>
                        })}
                    }
                </ul>
            ) : null
            }
        </div >
    )
}
