import React from 'react'
import { useSelector, useDispatch } from 'react-redux'
import { ordered, restocked } from './cakeSlice'

export const CakeView = () => {
    const [value, setValue] = React.useState(1);
    const dispatch = useDispatch()
    const numberOfCake = useSelector((state) => state.cake.numberOfCake) // reducer slice name accessing numberOfCakeState that are getting stored in prop numberOfCake
    return (
        <div>
            <h2>Number of Cakes - {numberOfCake} </h2>
            <button onClick={() => dispatch(ordered())}>Order Cake</button>
            <input
                type="number"
                value={value}
                onChange={(text) => {
                    setValue(parseInt(text.target.value))
                }} />
            <button onClick={() => dispatch(restocked(value))}>Restoke Cake</button>
        </div>
    )
}
