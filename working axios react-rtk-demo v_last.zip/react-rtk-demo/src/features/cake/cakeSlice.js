import { createSlice } from '@reduxjs/toolkit'

const initialState = {
  numberOfCake: 10,
};

const cakeSlice = createSlice({
  // the func accept 3 properties name, initial state, reducers
  name: "cake",
  initialState, // or we can write as well - initialState: initialState,
  reducers: {
    ordered: (state) => {
      // function accept two params state and action
      // we don't need action as there is no payload
      state.numberOfCake--;
    },
    restocked: (state, action) => {
      // function accept two params state and action
      // we need action as there is some payload
      state.numberOfCake += action.payload;
    },
  },
});

export default cakeSlice.reducer;
export const { ordered, restocked } = cakeSlice.actions;
