import { configureStore } from "@reduxjs/toolkit";
import ThunkMiddleware from "redux-thunk";

import cakeReducer from "../features/cake/cakeSlice";
import icecreamReducer from "../features/icecream/icecreamSlice";
import userReducer from "../features/user/userSlice";
import { fetchUsers } from "../features/user/userSlice";

const store = configureStore({
  reducer: {
    cake: cakeReducer,
    icecream: icecreamReducer,
    user: userReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(ThunkMiddleware),
}
);

export default store;
store.dispatch(fetchUsers())


